#include "xil_types.h"

u8 testRegister(UINTPTR baseAddr, u32 expectedMax, u32 expectedLow);