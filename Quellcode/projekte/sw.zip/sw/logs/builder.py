# 2025-06-25T21:06:40.396459
import vitis

client = vitis.create_client()
client.set_workspace(path="/home/xuser/pmod-maxsonar-pmod-clp/Quellcode/src/sw")

platform = client.create_platform_component(name = "hw-platform",hw = "/home/xuser/pmod-maxsonar-pmod-clp/Quellcode/src/hw-platform/hw-platform.xsa",os = "standalone",cpu = "microblaze_0")

platform = client.get_platform_component(name="hw-platform")
status = platform.build()

comp = client.create_app_component(name="sw-code",platform = "/home/xuser/pmod-maxsonar-pmod-clp/Quellcode/src/sw/hw-platform/export/hw-platform/hw-platform.xpfm",domain = "standalone_microblaze_0")

comp = client.get_component(name="sw-code")
comp.build()

vitis.dispose()

